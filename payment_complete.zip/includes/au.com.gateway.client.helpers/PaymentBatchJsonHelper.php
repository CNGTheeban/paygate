<?php

class PaymentBatchJsonHelper {
    
}
