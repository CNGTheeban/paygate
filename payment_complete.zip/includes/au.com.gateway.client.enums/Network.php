<?php

class Network {
    
    public static $LIVE = "LIVE";
    public static $TEST = "TEST";
}
