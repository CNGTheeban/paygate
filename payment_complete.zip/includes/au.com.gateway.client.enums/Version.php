<?php

class Version {

    public static $VERSION_1_01 = "1.01";
    public static $VERSION_1_02 = "1.02";
    public static $VERSION_1_03 = "1.03";
    public static $VERSION_1_04 = "1.04";
    public static $VERSION_LATEST = "1.04";

    private function __construct() {
        
    }

}
